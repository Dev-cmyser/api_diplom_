from django.contrib import admin
from demo.models import *
admin.site.register(User)
admin.site.register(Task)
admin.site.register(App)
